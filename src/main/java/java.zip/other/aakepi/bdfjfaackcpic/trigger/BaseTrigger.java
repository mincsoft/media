package other.aakepi.bdfjfaackcpic.trigger;


import other.aakepi.bdfjfaackcpic.api.BaseApiSupport;

/**
 * 基础对象
 */
public abstract class BaseTrigger extends BaseApiSupport {

}
